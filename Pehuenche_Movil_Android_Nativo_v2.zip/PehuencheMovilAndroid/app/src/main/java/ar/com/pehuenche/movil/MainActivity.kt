package ar.com.pehuenche.movil

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView

private val Navy = Color(0xFF123B60)
private val Blue = Color(0xFF1769AA)
private val Pale = Color(0xFFF2F6FA)
private val Ink = Color(0xFF1D2B38)
private val Muted = Color(0xFF718096)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Configuration.getInstance().userAgentValue = packageName
        setContent { PehuencheApp() }
    }
}

private enum class Tab(val label: String, val icon: ImageVector) {
    HOME("Inicio", Icons.Default.Home),
    SERVICES("Servicios", Icons.Default.DirectionsBus),
    MAP("Mapa", Icons.Default.Map),
    TIMES("Horarios", Icons.Default.Schedule),
    SAVED("Favoritos", Icons.Default.Favorite)
}

private data class Service(val name: String, val subtitle: String, val icon: ImageVector)
private val services = listOf(
    Service("Servicios provinciales", "Conexiones entre localidades", Icons.Default.Route),
    Service("Urbano Centenario", "Servicios dentro de Centenario", Icons.Default.DirectionsBus),
    Service("Servicios interurbanos", "Conexiones regionales", Icons.Default.Commute),
    Service("Urbano Cipolletti", "Servicios dentro de Cipolletti", Icons.Default.DirectionsBus)
)

@Composable
private fun PehuencheApp() {
    var selected by remember { mutableStateOf(Tab.HOME) }
    var search by remember { mutableStateOf("") }
    val favorites = remember { mutableStateListOf<String>() }
    Scaffold(
        containerColor = Pale,
        bottomBar = {
            NavigationBar(containerColor = Color.White, tonalElevation = 8.dp) {
                Tab.values().forEach { tab ->
                    NavigationBarItem(
                        selected = selected == tab,
                        onClick = { selected = tab },
                        icon = { Icon(tab.icon, contentDescription = tab.label) },
                        label = { Text(tab.label, fontSize = 11.sp) },
                        colors = NavigationBarItemDefaults.colors(selectedIconColor = Blue, indicatorColor = Color(0xFFE4F0FA), selectedTextColor = Blue)
                    )
                }
            }
        }
    ) { padding ->
        when (selected) {
            Tab.HOME -> HomeScreen(padding, search, { search = it }, { selected = Tab.SERVICES }, { selected = Tab.MAP }, { selected = Tab.TIMES })
            Tab.SERVICES -> ServicesScreen(padding, search, { search = it }, favorites) 
            Tab.MAP -> MapScreen(padding)
            Tab.TIMES -> ScheduleScreen(padding)
            Tab.SAVED -> FavoritesScreen(padding, favorites)
        }
    }
}

@Composable
private fun Header(title: String, subtitle: String? = null) {
    Column(
        Modifier.fillMaxWidth().background(Navy).padding(horizontal = 20.dp, vertical = 18.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.DirectionsBus, null, tint = Color.White, modifier = Modifier.size(27.dp))
            Spacer(Modifier.width(9.dp))
            Text("PEHUENCHE", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 19.sp, letterSpacing = 1.2.sp)
            Spacer(Modifier.weight(1f))
            Text("NEUQUÉN", color = Color(0xFFBBD9F2), fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
        if (subtitle != null) {
            Spacer(Modifier.height(17.dp))
            Text(title, color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(3.dp))
            Text(subtitle, color = Color(0xFFD3E4F2), fontSize = 13.sp)
        }
    }
}

@Composable
private fun HomeScreen(padding: PaddingValues, search: String, onSearch: (String) -> Unit, onServices: () -> Unit, onMap: () -> Unit, onTimes: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(padding)) {
        Header("¿A dónde querés ir?", "Encontrá servicios y consultá información de Pehuenche")
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            OutlinedTextField(
                value = search, onValueChange = onSearch, modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("Buscar localidad o servicio") }, leadingIcon = { Icon(Icons.Default.Search, null) },
                shape = RoundedCornerShape(16.dp), singleLine = true, colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Blue, unfocusedBorderColor = Color(0xFFD8E1E9), focusedContainerColor = Color.White, unfocusedContainerColor = Color.White)
            )
            Text("Explorá Pehuenche", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Ink)
            services.forEach { service -> ServiceCard(service, false, {}) }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                ActionTile("Ver mapa", Icons.Default.Map, Modifier.weight(1f), onMap)
                ActionTile("Todos los servicios", Icons.Default.DirectionsBus, Modifier.weight(1f), onServices)
            }
            ActionTile("Consultar horarios", Icons.Default.Schedule, Modifier.fillMaxWidth(), onTimes)
            NoticeCard()
        }
    }
}

@Composable
private fun ServicesScreen(padding: PaddingValues, search: String, onSearch: (String) -> Unit, favorites: MutableList<String>) {
    val filtered = services.filter { (it.name + " " + it.subtitle).contains(search, ignoreCase = true) }
    Column(Modifier.fillMaxSize().padding(padding)) {
        Header("Servicios", "Elegí el tipo de servicio que necesitás")
        Column(Modifier.padding(16.dp)) {
            OutlinedTextField(value = search, onValueChange = onSearch, modifier = Modifier.fillMaxWidth(), placeholder = { Text("Buscar servicio") }, leadingIcon = { Icon(Icons.Default.Search, null) }, shape = RoundedCornerShape(16.dp), singleLine = true)
            Spacer(Modifier.height(14.dp))
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(filtered) { service ->
                    ServiceCard(service, service.name in favorites) {
                        if (service.name in favorites) favorites.remove(service.name) else favorites.add(service.name)
                    }
                }
                item { NoticeCard() }
            }
        }
    }
}

@Composable
private fun ServiceCard(service: Service, favorite: Boolean, onFavorite: () -> Unit) {
    Card(shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Color.White), elevation = CardDefaults.cardElevation(1.dp), modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(46.dp).background(Color(0xFFE8F2FA), CircleShape), contentAlignment = Alignment.Center) {
                Icon(service.icon, null, tint = Blue, modifier = Modifier.size(24.dp))
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(service.name, fontWeight = FontWeight.Bold, color = Ink, fontSize = 14.sp)
                Spacer(Modifier.height(3.dp))
                Text(service.subtitle, color = Muted, fontSize = 12.sp)
            }
            IconButton(onClick = onFavorite) { Icon(if (favorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder, null, tint = if (favorite) Color(0xFFD64C66) else Muted) }
        }
    }
}

@Composable
private fun ActionTile(title: String, icon: ImageVector, modifier: Modifier, onClick: () -> Unit) {
    Card(modifier.clickable(onClick = onClick), shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
        Column(Modifier.fillMaxWidth().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(icon, null, tint = Blue, modifier = Modifier.size(25.dp))
            Spacer(Modifier.height(7.dp))
            Text(title, color = Ink, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
        }
    }
}

@Composable
private fun NoticeCard() {
    Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFFEAF2F8))) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.Top) {
            Icon(Icons.Default.Info, null, tint = Blue)
            Spacer(Modifier.width(10.dp))
            Column {
                Text("Datos y seguimiento", fontWeight = FontWeight.Bold, color = Navy, fontSize = 13.sp)
                Spacer(Modifier.height(4.dp))
                Text("Los horarios publicados por Pehuenche ya están incorporados en la sección Horarios. El mapa muestra la cartografía de la zona; la ubicación GPS de cada colectivo requiere acceso a la interfaz de datos de Micronauta, que todavía no está documentada públicamente.", color = Color(0xFF42566A), fontSize = 12.sp, lineHeight = 17.sp)
            }
        }
    }
}

@Composable
private fun MapScreen(padding: PaddingValues) {
    val context = LocalContext.current
    Column(Modifier.fillMaxSize().padding(padding)) {
        Header("Mapa", "Neuquén y alrededores")
        AndroidView(
            modifier = Modifier.weight(1f).fillMaxWidth(),
            factory = {
                MapView(it).apply {
                    setTileSource(TileSourceFactory.MAPNIK)
                    setMultiTouchControls(true)
                    controller.setZoom(11.5)
                    controller.setCenter(GeoPoint(-38.9516, -68.0591))
                }
            }
        )
        NoticeCard()
    }
}

private data class Schedule(
    val category: String,
    val route: String,
    val first: String? = null,
    val interval: Int? = null,
    val last: String? = null,
    val detail: String? = null
)

// Horarios y frecuencias publicados en el sitio oficial de Pehuenche.
private val schedules = listOf(
    Schedule("Servicios interurbanos", "Ramal A", "04:50", 17, "23:25"),
    Schedule("Servicios interurbanos", "Ramal B", "05:35", 60, "00:25"),
    Schedule("Servicios interurbanos", "Neuquén – Centenario – Cinco Saltos", "05:40", 47, "23:35"),
    Schedule("Servicios interurbanos", "Neuquén – Cipolletti – Cinco Saltos", "06:15", 70, "23:10"),
    Schedule("Servicios interurbanos", "Neuquén – San Patricio del Chañar", "05:15", 60, "01:10"),
    Schedule("Servicios interurbanos", "San Patricio del Chañar – Añelo", detail = "Desde Chañar: 06:40 · 12:00 · 17:30\nDesde Añelo: 08:10 · 13:30 · 18:40"),
    Schedule("Servicios provinciales", "Neuquén – Centenario", "04:45", 14, "01:10"),
    Schedule("Servicios provinciales", "Dique – Vista Alegre Norte – Neuquén", "06:00", 90, "23:35"),
    Schedule("Servicios provinciales", "Centenario – Costa Reyes – Vista Alegre Sur", "06:25", 80, "22:45"),
    Schedule("Urbano Centenario", "Ramal 40", "06:30", 60, "21:25"),
    Schedule("Urbano Centenario", "Ramal 60", "07:00", 60, "19:55"),
    Schedule("Urbano Centenario", "Villa Obrera – Nueva España", detail = "Cuatro salidas diarias escolares. La página oficial no publica aquí los horarios exactos."),
    Schedule("Urbano Cipolletti", "Costa Norte – Distrito Noreste", "06:14", 32, "22:23"),
    Schedule("Urbano Cipolletti", "Ramal Único", "06:05", 40, "22:29"),
    Schedule("Urbano Cipolletti", "Ramal Puente 83", "06:30", 60, "22:00"),
    Schedule("Servicio nacional", "Neuquén – Catriel – 25 de Mayo", detail = "Salida desde Neuquén: 07:00 · Regreso desde 25 de Mayo: 12:00")
)

@Composable
private fun ScheduleScreen(padding: PaddingValues) {
    var query by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("Todos") }
    val categories = listOf("Todos", "Servicios provinciales", "Servicios interurbanos", "Urbano Centenario", "Urbano Cipolletti", "Servicio nacional")
    val filtered = schedules.filter {
        (category == "Todos" || it.category == category) &&
            (it.route + " " + it.category).contains(query, ignoreCase = true)
    }
    Column(Modifier.fillMaxSize().padding(padding)) {
        Header("Horarios", "Servicios publicados por Pehuenche")
        OutlinedTextField(
            value = query, onValueChange = { query = it }, modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
            placeholder = { Text("Buscar ramal o localidad") }, leadingIcon = { Icon(Icons.Default.Search, null) },
            shape = RoundedCornerShape(14.dp), singleLine = true
        )
        androidx.compose.foundation.lazy.LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(categories) { item ->
                FilterChip(selected = category == item, onClick = { category = item }, label = { Text(item, fontSize = 11.sp) })
            }
        }
        LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(filtered) { schedule ->
                Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                    Column(Modifier.fillMaxWidth().padding(15.dp)) {
                        Text(schedule.category.uppercase(), color = Blue, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = .6.sp)
                        Spacer(Modifier.height(4.dp))
                        Text(schedule.route, color = Ink, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(8.dp))
                        if (schedule.first != null) {
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                InfoPill("Primera", schedule.first)
                                InfoPill("Frecuencia", "Cada ${schedule.interval} min")
                                InfoPill("Última", schedule.last ?: "—")
                            }
                        }
                        if (schedule.detail != null) {
                            Spacer(Modifier.height(4.dp))
                            Text(schedule.detail, color = Color(0xFF526477), fontSize = 12.sp, lineHeight = 18.sp)
                        }
                    }
                }
            }
            item {
                Text("Fuente: página oficial de horarios de Pehuenche. Las frecuencias son las publicadas por la empresa y pueden variar por día, feriados o cambios del servicio.", color = Muted, fontSize = 11.sp, lineHeight = 16.sp, modifier = Modifier.padding(vertical = 8.dp))
            }
        }
    }
}

@Composable
private fun InfoPill(label: String, value: String) {
    Column(Modifier.background(Color(0xFFEAF2F8), RoundedCornerShape(10.dp)).padding(horizontal = 9.dp, vertical = 7.dp)) {
        Text(label, color = Muted, fontSize = 9.sp)
        Text(value, color = Navy, fontSize = 11.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun FavoritesScreen(padding: PaddingValues, favorites: List<String>) {
    Column(Modifier.fillMaxSize().padding(padding)) {
        Header("Favoritos", "Tus servicios guardados")
        if (favorites.isEmpty()) {
            Column(Modifier.fillMaxWidth().padding(32.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Default.FavoriteBorder, null, tint = Muted, modifier = Modifier.size(42.dp))
                Spacer(Modifier.height(10.dp))
                Text("Todavía no tenés favoritos", color = Ink, fontWeight = FontWeight.Bold)
                Text("Guardá servicios desde la sección Servicios.", color = Muted, fontSize = 13.sp)
            }
        } else {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                favorites.forEach { name ->
                    val service = services.firstOrNull { it.name == name }
                    if (service != null) ServiceCard(service, true) {}
                }
            }
        }
    }
}
