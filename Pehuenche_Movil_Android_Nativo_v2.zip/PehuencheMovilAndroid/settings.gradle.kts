pluginManagement {
    repositories {
        google()
        // Mirror de Maven Central para evitar fallos intermitentes al descargar dependencias.
        maven { url = uri("https://maven-central.storage-download.googleapis.com/maven2/") }
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        // Mirror de Maven Central para dependencias transitivas del Android Gradle Plugin.
        maven { url = uri("https://maven-central.storage-download.googleapis.com/maven2/") }
        mavenCentral()
    }
}
rootProject.name = "PehuencheMovil"
include(":app")
