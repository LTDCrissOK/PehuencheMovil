# Pehuenche Móvil (Android nativo)

Proyecto Android nativo desarrollado con Kotlin y Jetpack Compose. No utiliza WebView para mostrar la web de Micronauta.

## Funciones incluidas
- Inicio y navegación nativa.
- Categorías de servicios Pehuenche.
- Buscador de servicios.
- Favoritos locales en memoria durante la sesión.
- Mapa OpenStreetMap centrado en Neuquén.
- Pantalla de horarios y frecuencias publicados por Pehuenche, con filtros por tipo de servicio.

## Datos de horarios
Los datos de primera salida, frecuencia y última salida se transcribieron de la página oficial:
https://pehuenche.com.ar/horarios-de-los-ramales.html

La página publica frecuencias generales para varios ramales y algunos horarios puntuales. No publica en esa tabla el horario de paso por cada parada.

## Limitación importante: seguimiento GPS
El portal Micronauta muestra módulos de recorridos y seguimiento, pero el acceso consultable de la página pública no expone una API documentada ni sus endpoints de unidades, rutas o paradas. Por eso esta versión no inventa posiciones de colectivos y el mapa muestra únicamente la cartografía base. Para añadir GPS en vivo, ETA y geometrías oficiales hace falta obtener la API/credenciales o documentación de Micronauta/Pehuenche, o inspeccionar legalmente las solicitudes de red que utiliza el portal.

## Compilar
Requisitos: Android Studio actual, JDK 17, Android SDK 35.

Abrir este directorio en Android Studio y ejecutar `app` o `Build > Build Bundle(s) / APK(s) > Build APK(s)`.

También se incluye GitHub Actions en `.github/workflows/android.yml`; al subir el proyecto a GitHub se puede ejecutar desde Actions y descargar el artefacto `Pehuenche-Movil-debug-apk`.
